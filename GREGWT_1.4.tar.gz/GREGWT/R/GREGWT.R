# Created by Esteban Munoz (emunozh@gmail.com).
#
# 13.10.2014
#
library(MASS)

dependent.variables <- function(X, att.num, cor.lim=FALSE){
    if(!cor.lim){cor.lim=sum(cor(X),na.rm=TRUE)/dim(X)[2]/2}
    cat("cor.lim=",cor.lim," ")
    index <- vector()
    found = 0
    for(i in seq(2, att.num)){
        c <- cor(X[,1:i])
        cor.found = (sum(c>=cor.lim,na.rm=TRUE) + sum(c<=-cor.lim,na.rm=TRUE))
        if(!cor.found){cor.found=Inf}
        if((cor.found -i -found*2) > 0){
            cat("x")
            index <- append(index, i)
            found = found + 1}}
    return(index)}

getA <- function(X, dx, att.num){
    A <- matrix(0, att.num, att.num)
    for(i in seq(att.num)){
        A[,i] <- colSums(dx * X * X[,i])}
    #Ai <- solve(A)
    Ai <- ginv(A)
    return(Ai)}

getNewWeights <- function(X,dx,Tx,Ai){
    Tx <- as.matrix(Tx)
    X <- as.matrix(X)
    # Sample totals
    that_xs <- colSums(X*dx)
    # Lagrange multipliers
    lambda = Ai %*% (Tx - that_xs)
    # New weights
    # temp = dx + dx * X
    wx = dx + dx * X %*% lambda
    wx = wx[,1]
    return(wx)}

getAOld <- function(X, dx, att.num, Tx){
    a <- matrix(0, att.num, att.num)
    for(i in seq(att.num)){a[,i] <- colSums(dx * X * X[,i])}
    b = Tx - colSums(X*dx)
    A <- solve(a, b)
    return(A)}

getNewWeightsOld <- function(X,dx,Tx,Ai){
    wx = dx * (1+Ai%*%t(X))
    return(t(wx))}

groupX <- function(X, group){
    X.g <- aggregate(X, by=list(X[,group]), FUN=sum)
    X.g <- X.g[names(X.g)!=group]
    #X.g <- as.matrix(X.g)
    return(X.g)}

groupDx <- function(X.input, dx, group){
    dx.g <- aggregate(dx, by=list(X.input[,group]), FUN=sum)
    dx.g <- as.matrix(dx.g)
    dx.g <- as.numeric(dx.g[,"x"])
    return(dx.g)}

#expandGroup <- function(X.g, wx, X.input, group){
#    weights <- vector(length=dim(X.input)[1])
#    for(i in seq(length(wx))){
#        weights[X.input[,group] == X.g[i,"Group.1"]] <- wx[i]}
#    return(weights)}

#findW <- function(i,wx,X.g){wx[which(X.g==i)]}
#
#expandGroup <- function(X.g, wx, X.input, group){
#    weights <- sapply(as.matrix(X.input[,group]), findW, wx=wx, X.g=X.g)
#    return(weights)}

expandGroup <- function(X.g, wx, X.input, group){
    Origin <- X.g[,"Group.1"]
    Grouped <- X.input[,group]
    index <- match(Grouped, Origin, nomatch=0) 
    weights <- wx[index]
    return(weights)}

GREGWTest <- function(X, dx, Tx,
                      # Optional variables
                      group=FALSE,
                      bounds=c(-Inf,Inf),
                      epsilon=0.001,
                      max.iter=10,
                      X.input=FALSE,
                      dx.input=FALSE){

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################
    # bench ################

    cat("GREGWT ")
      
    # Save the aggregation ids
    X.g <- X
    #Tx.buk <- Tx 

    if(class(group) == "character"){
        X <- X[,colnames(X)[colnames(X)!="Group.1"]]}

    # number of attributes in the input sample
    att.num <- dim(X)[2]

    # Ai
    #save.image(file="Ai.BData")
    Ai.m1 <- getA(X,dx,att.num)
    #Ai.m1 <- getA(X,dx,att.num,Tx)

    # truncate weights
    Covergence = FALSE
    number.iter = 0
    while(Covergence == FALSE){
        cat(".")
        number.iter = number.iter + 1
        wx <- getNewWeights(X, dx, Tx, Ai.m1)
        wx[wx<bounds[1]] <- bounds[1]
        wx[wx>bounds[2]] <- bounds[2]
        
        dx[wx<bounds[1]] <- 0
        dx[wx>bounds[2]] <- 0
        
        Ai.t <- getA(X,dx,att.num)
        #Ai.t <- getA(X,dx,att.num,Tx)
        Ai.m <- Ai.m1 + Ai.t
        Covergence <- (
                all(abs(Tx-colSums(X*wx)) < epsilon) |
                all(abs(Ai.m-Ai.m1) < epsilon) |
                max.iter > number.iter)
        Ai.m1 <- Ai.m}
    cat("OK\t")

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench 3:", t.delta, "\t")
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    #save.image(file="Expand.BData")
    if(class(group) == "character"){
        cat("Expanding group ")
        #weights <- expandGroup(wx, X.input[,group], X.g[,"Group.1"])
        weights <- expandGroup(X.g, wx, X.input, group)
        dx.output=dx.input
        wx.output=weights
    }else{
        dx.output=dx
        wx.output=wx}

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench 4:", t.delta, "\t")
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    list(Input.Weights=dx.output, Final.Weights=wx.output)}

prepareData <- function(X,Tx,cor.lim=FALSE, group=FALSE){
    cat("preparing data ")

    X <- X[, order(colnames(X))]
    Tx <- Tx[, order(colnames(Tx))]

    Xin  <- X
    if(sum(names(Xin)=="Group.1")==1){X <- X[names(X) != "Group.1"]}

    Tx <- as.data.frame(Tx)
    Xo <- X[colSums(X,na.rm=TRUE) != 0 & colSums(X,na.rm=TRUE) != dim(X)[1]]
    Txo <- Tx[colSums(X,na.rm=TRUE) != 0 & colSums(X,na.rm=TRUE) != dim(X)[1]]

    if(class(Xo) == "data.frame"){Xo <- data.matrix(Xo)}
    Xo <- as.matrix(Xo)

    if(class(Txo) == "data.frame"){Txo <- data.matrix(Txo)}
    Txo <- as.matrix(Txo)

    if(dim(Xo)[2] != dim(Txo)[2]){cat("Error! Dimension mismatch\n")}

    # check is there are dependent variables in the matrix 
    index <- dependent.variables(Xo, dim(Xo)[2], cor.lim=cor.lim)
    if(!is.logical(index)){
        Xo <- Xo[,-index]
        Txo <- Txo[,-index]}
    
    if(sum(names(Xin)=="Group.1")==1){Xo <- cbind(Xo, Xin["Group.1"])}

    cat("OK\t")
    return(list(X=Xo, Tx=Txo))}


GREGWT <- function(x, ...) UseMethod("GREGWT")

GREGWT.default <- function(X, dx, Tx,
                           group=FALSE,
                           bounds=c(-Inf,Inf),
                           epsilon=0.001,
                           max.iter=10,
                           prepare.data=TRUE,
                           cor.lim=1){

    # bench ################
    # bench ################
    # bench ################
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    Tx <- as.data.frame(Tx)

    if(class(group) == "logical"){
        group <- as.logical(group)
    }else{
        group <- as.character(group)}

    X.input <- X
    dx.input <- dx
    if(class(group) == "character"){
        cat("grouping to:", group, "\t")
        X <- groupX(X, group)
        dx <- groupDx(X.input, dx, group)
    }else{
        X.input=FALSE
        dx.input=FALSE}

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench 1:", t.delta, "\t")
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################
    
    #save.image(file="prepareData.BData")
    #load("prepareData.BData")

    if(prepare.data){
        result <- prepareData(X,Tx,cor.lim=cor.lim)
        X <- result$X
        Tx <- result$Tx}

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench 2:", t.delta, "\t")
    # bench ################
    # bench ################
    # bench ################

    dx <- as.numeric(dx)
    Tx <- as.numeric(Tx)
    bounds <- as.numeric(bounds)
    epsilon <- as.numeric(epsilon)
    max.iter <- as.numeric(max.iter)

    #save.image(file="startG.BData")

    model <- GREGWTest(X, dx, Tx,
                        group=group,
                        bounds=bounds,
                        epsilon=epsilon,
                        max.iter=max.iter,
                        X.input=X.input,
                        dx.input=dx.input)
    cat("OK\t")

    model$call <- match.call()
    wf <- model$Final.Weights 
    wi <- model$Input.Weights 
    # Total absolute distance
    model$TAD <- sum(abs(wf-wi))
    # Weights Distance
    model$Distance.Weights <- wf - wi
    # Chi-squared distance
    model$Distance.Chi2 <- 1/2 * (wf - wi)^2 / wi
    # Total Chi-squared distance
    model$TDistance.Chi2 <- sum(1/2 * (wf - wi)^2 / wi)
    # Originall survey matrix
    if(class(group) == "character"){
        model$survey <- X.input
    }else{
        model$survey <- X}
    class(model) <- "GREGWT"
    model}

print.GREGWT <- function(x, ...){
    cat("Call:\n")
    print(x$call)
    cat("\nMean Weight Distance [wx - dx]:\n")
    print(mean(x$Distance.Weights))
    cat("\nMean Chi-squared Distance [sum(1/2 * (wx -dx)^2 / dx)]:\n")
    print(mean(x$Distance.Chi2))
    cat("\nTotal Chi-squared Distance [mean(1/2 * (wx -dx)^2 / dx)]:\n")
    print(x$TDistance.Chi2)
    cat("\nTotal absolute distance [sum(abs(wx - dx))]:\n")
    print(x$TAD)
    cat("\nNew Weights. Access via: X$Final.Weights:\n")
    print(paste(length(x$Final.Weights),"New weights"))}

summary.GREGWT <- function(object, ...){
    TAB <- cbind(M.Weight.D = mean(object$Distance.Weights),
                 M.Chi2.D = mean(object$Distance.Chi2),
                 T.Chi2.D = object$TDistance.Chi2,
                 T.A.D = object$TAD)
    res <- list(call=object$call,
                Distance=TAB)
    class(res) <- "summary.GREGWT"
    res}

print.summary.GREGWT <- function(x, ...){
    cat("Call:\n")
    print(x$call)
    cat("\n")
    printCoefmat(x$Distance)}

Synthetize <- function(x, ...) UseMethod("Synthetize")

Synthetize.default <- function(gregwt.object, pop.size.input,
                          method=c("random", 1),
                          group = FALSE,
                          HHsize.mean.fit = 1.8,
                          max.iter = 100,
                          fit.tolerance = 0.1,
                          random.seed=12345,
                          benchmarks=NULL,
                          output=FALSE){

    model <- Synthetizeget(gregwt.object, pop.size.input,
                           method=method,
                           group = group,
                           HHsize.mean.fit = HHsize.mean.fit,
                           max.iter = max.iter,
                           fit.tolerance = fit.tolerance,
                           random.seed=random.seed,
                           benchmarks=benchmarks,
                           output=output)

    model <- as.data.frame(model)
    model}

findBest <- function(result, n.samples, benchmarks, pop.size=FALSE){
    bench.names <- names(benchmarks)
    result.name <- dimnames(result)[[2]]
    index <- sapply(result.name,"%in%",bench.names)
    c.sums <- result[,index,]

    if(dim(result)[1]==1){
        # If there is a single person in the sample
        TAE.sample <- sum(colSums(c.sums,na.rm=TRUE))
    }else{
        TAE.sample <- colSums(colSums(c.sums,na.rm=TRUE))}

    TAE.benchm <- sum(benchmarks)
    TAE.m <- abs(TAE.sample - TAE.benchm)

    TAE.index <- which(TAE.m == min(TAE.m))

    if(pop.size){
        # Resulting sample, count people
        if(dim(result)[1]==1){
            # If there is a single person in the sample
            rs = sum(!is.nan(result[,1,1]))
        }else{
            rs <- rowSums(!is.nan(aperm(result[,1,])))}

        diff.pop <- abs(rs-pop.size) 
        result.index <- which(diff.pop == min(diff.pop) & TAE.m == min(TAE.m))

        tolerance = 0
        increase.rate = 1
        while(length(result.index)==0){
            result.index <- which(diff.pop == min(diff.pop) &
                TAE.m <= min(TAE.m)+tolerance)
            tolerance = tolerance + increase.rate}

    }else{result.index <- TAE.index}
    return(result[,,result.index[1]])}

fillPop <- function(synthetic.pop, expected.dim){
    gap <- expected.dim - dim(synthetic.pop)[1]
    #cat("I have a gap of:", gap)
    if(gap>=1){
        #cat(" adding",gap,"individuals\n")
        fill <- vector(length=(dim(synthetic.pop)[2]))
        fill[] <- NaN
        for(i in seq(1,abs(gap))){
            synthetic.pop <- rbind(synthetic.pop, fill)}
    }else{
        to.index = dim(synthetic.pop)[1]+gap
        #cat(" to index:", to.index,"\n")
        synthetic.pop <- synthetic.pop[1:to.index,]}
    return(synthetic.pop)}

Synthetizeget <- function(gregwt.object, pop.size.input,
                          method=c("random", 1),
                          group = FALSE,
                          HHsize.mean.fit = 1.8,
                          max.iter = 100,
                          fit.tolerance = 0.1,
                          random.seed=12345,
                          benchmarks=NULL,
                          output=FALSE){

    # bench ################
    # bench ################
    # bench ################
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    # set the random seed to ensure reproducibility
    set.seed(random.seed)

    # define number of samples to take from the survey
    n.samples = as.numeric(method[2])

    # prepare array for synthetic population
    survey <- gregwt.object$survey

    if(class(output)!="logical"){survey <- cbind(survey, output)}

    result=array(NaN, dim=c(pop.size.input, dim(survey)[2], n.samples))
    dimnames(result) <- list(NULL,colnames(survey),NULL)

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench 5:", t.delta, "\t")
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    if(class(group) == "character"){

        X <- as.data.frame(gregwt.object$survey)

        X.g <- data.frame(HHid=X[,group], HHsize=(vector(length=dim(X)[1])+1)) 
        X.g <- aggregate(X.g, by=list(X[,group]), FUN=sum)
        X.g <- X.g[names(X.g)!=group]

        wx <- gregwt.object$Final.Weights
        wx.g <- aggregate(wx, by=list(X[,group]), FUN=mean)
        wx.g <- as.matrix(wx.g)
        wx.g <- as.numeric(wx.g[,"x"])
        mean.w <- mean(wx.g)

        pop.size.sel = pop.size.input / HHsize.mean.fit

        for(i in seq(1,n.samples)){
            HHsize.mean.sel = 0 
            HHsize.sum.sel = 0
            HHsize.delta = Inf
            Popsize.delta = Inf
            iter.num = 0
            while(!(HHsize.mean.fit < HHsize.mean.sel+fit.tolerance  & 
                    HHsize.mean.fit > HHsize.mean.sel-fit.tolerance) | 
                    pop.size.input != HHsize.sum.sel
                    ){
                if(iter.num == max.iter) break
                iter.num = iter.num + 1
                pop.index <- sample(
                    nrow(X.g), pop.size.sel, replace=TRUE, prob=wx.g)
                pop.sel.temp <- X.g[pop.index, ]
                HHsize.mean.sel.temp <- mean(pop.sel.temp$HHsize)
                #cat("household size: ", HHsize.mean.sel.temp, "\n")
                HHsize.sum.sel.temp <- sum(pop.sel.temp$HHsize)
                if((abs(HHsize.mean.sel.temp-HHsize.mean.fit)<HHsize.delta) &&
                   (abs(HHsize.sum.sel.temp- pop.size.input) <Popsize.delta)){
                    HHsize.mean.sel <- HHsize.mean.sel.temp 
                    HHsize.delta <- abs(HHsize.mean.sel-HHsize.mean.fit)
                    HHsize.sum.sel <- HHsize.sum.sel.temp
                    Popsize.delta <- abs(HHsize.sum.sel-pop.size.input)
                    pop.sel <- pop.sel.temp
                }else{
                    #HHsize.delta.2 <- HHsize.mean.sel-HHsize.mean.fit
                    if(HHsize.mean.sel > HHsize.mean.fit){
                        this.index = X.g$HHsize <= HHsize.mean.fit
                    }else{
                        this.index = X.g$HHsize >= HHsize.mean.fit}
                    wx.g[this.index] <- wx.g[this.index] + mean.w}}

            #if(iter.num == max.iter){
            #    cat("Warning! Couldn't find a solution\t")
            #}else{cat("found a solution\t")}
            #cat("HHsize want",HHsize.mean.fit,"got:",HHsize.mean.sel)
            #cat("Pop    want",HHsize.sum.sel,"got:",pop.size.input,"\n")

            synthetic.pop <- data.frame(
                matrix(NA, nrow=0, ncol=dim(survey)[2]))
            names(synthetic.pop) <- names(survey)

            p <- pop.sel$Group.1 
            for(j in seq(length(p))){
                spp <- survey[which(X[,group] == p[j]), ]
                spp[group] <- j
                synthetic.pop <- rbind(synthetic.pop, spp)}

            if(dim(result)[1] != dim(synthetic.pop)[1]){
                #cat("people!\t got:", dim(synthetic.pop)[1])
                #cat(" want:", dim(result)[1],"\n")
                synthetic.pop <- fillPop(synthetic.pop, dim(result)[1])}

            result[,,i] <- as.matrix(synthetic.pop)}
    }else{
        cat("ungrounded data")
        for(i in seq(1,n.samples)){
            index.survey <- sample(
                nrow(gregwt.object$survey), pop.size.input,
                replace=TRUE, prob=gregwt.object$Final.Weights)
            synthetic.pop <- survey[index.survey, ]
            result[,,i] <- as.matrix(synthetic.pop)}}

    #save.image(file="findBest.BData")
    #load("findBest.BData")
    #pop.size <- pop.size.input

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench 6:", t.delta, "\t")
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    switch(method[1],
        "random"={result=result},
        "best"={result=findBest(result, n.samples, benchmarks)},
        "bestHH"={
            result=findBest(result, n.samples, benchmarks, pop.size.input)
        },
        result=NULL)

    # bench ################
    # bench ################
    # bench ################
    # bench ################
    # t.delta <- Sys.time()-t0
    # cat("#Bench: 7", t.delta, "\t")
    # t0 <- Sys.time()
    # bench ################
    # bench ################
    # bench ################

    return(result)}
